/**
 * 
 */
package prj5;

import student.TestCase;

/**
 * @author Carolyn Johnson (carolynj)
 * @version 2017.04.19
 */
public class MixtapeTest extends TestCase {

    // Fields------------------------------------------------

    /**
     * Mixtape object to test with
     */
    private Mixtape tape;

    /**
     * Song object to use for testing
     */
    private Song song1;

    private Song song2;

    private Song song3;


    // setUp-------------------------------------------------

    /**
     * sets up the test cases and initializes the mixtape and song
     */
    public void setUp() {
        tape = new Mixtape();
        song1 = new Song("Low", "Flo Rida", "Hip Hop", 2003);
        song2 = new Song("Get Lucky", "Daft Punk", "Punk", 2005);
        song3 = new Song("22", "Taylor Swift", "pop", 2012);
    }

    // test methods------------------------------------------


    /**
     * tests the setList() method
     */
    public void testSetList() {
        // make list that tape will be set to
        LinkedList<Song> test = new LinkedList<>();
        test.add(song1);

        // set tape to initialized list
        tape.setList(test);

        // assert that tape's list is the same as what it was set to
        assertEquals(tape.getList(), test);
    }


    /**
     * tests the toArray() method
     */
    public void testToArray() {

        // add songs to the list in tape
        tape.addSong(song1);
        tape.addSong(song2);
        tape.addSong(song3);
        System.out.println(tape.toArray()[0]);
        System.out.println(tape.toArray()[1]);
        System.out.println(tape.toArray()[2]);
        assertEquals(tape.toArray()[0], song1);
        assertEquals(tape.toArray()[1], song2);
        assertEquals(tape.toArray()[2], song3);
    }


    public void testList() {

        tape.addSong(song1);
        tape.addSong(song2);
        tape.addSong(song3);
        assertTrue(tape.getList().contains(song1));
        assertTrue(tape.getList().contains(song2));
        assertTrue(tape.getList().contains(song3));
        assertEquals(tape.getList().size(), 3);
    }

}
