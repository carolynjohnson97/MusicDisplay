package prj5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Reads in data from files, creates a mixtape and party based on data
 * 
 * @author alexmann and carolynj
 * @version 04/19/17
 *
 */
public class FileReader {
    private Mixtape mix;
    private Song[] songArray;


    /**
     * Constructor instantiates files to parse and calls the GUI by giving it a
     * mixtape and party read from the files
     * 
     * @param file1
     *            Music survey data
     * @param file2
     *            songList
     * @throws FileNotFoundException
     */
    public FileReader(String file1, String file2) throws FileNotFoundException {
        File songInfo = new File(file2);
        File studentInfo = new File(file1);
        mix = readFile1(songInfo);

        SongOrganization genre = new SongOrganization(mix, "genre");
        SongOrganization title = new SongOrganization(mix, "title");

        songArray = mix.toArray();
        Party par = readFile2(studentInfo);

        // INTERMEDIATE SOLUTION OUTPUT
        for (int i = 0; i < mix.toArray().length; i++) {

            SortCategories thing = new SortCategories(((Song)genre.getNode(i + 1).getData()).getParty());

            System.out.println("Song Title: " + ((Song)genre.getNode(i + 1).getData()).getTitle());
            System.out.println("Song Artist: " + ((Song)genre.getNode(i + 1).getData()).getArtist());
            System.out.println("Song Genre: " + ((Song)genre.getNode(i + 1).getData()).getGenre());
            System.out.println("Song Year: " + ((Song)genre.getNode(i + 1).getData()).getYear());

            System.out.println("Heard");
            System.out.print("reading:");
            System.out.print((int)getPercHeard(thing, "reading"));
            System.out.print(" art:");
            System.out.print((int)getPercHeard(thing, "art"));
            System.out.print(" sports:");
            System.out.print((int)getPercHeard(thing, "sports"));
            System.out.print(" music:");
            System.out.println((int)getPercHeard(thing, "music"));

            System.out.println("Likes");
            System.out.print("reading:");
            System.out.print((int)getPercLiked(thing, "reading"));
            System.out.print(" art:");
            System.out.print((int)getPercLiked(thing, "art"));
            System.out.print(" sports:");
            System.out.print((int)getPercLiked(thing, "sports"));
            System.out.print(" music:");
            System.out.println((int)getPercLiked(thing, "music"));
            System.out.println();
        }

        for (int i = 0; i < mix.toArray().length; i++) {

            SortCategories thing = new SortCategories(((Song)title.getNode(i + 1).getData()).getParty());

            System.out.println("Song Title: " + ((Song)title.getNode(i + 1).getData()).getTitle());
            System.out.println("Song Artist: " + ((Song)title.getNode(i + 1).getData()).getArtist());
            System.out.println("Song Genre: " + ((Song)title.getNode(i + 1).getData()).getGenre());
            System.out.println("Song Year: " + ((Song)title.getNode(i + 1).getData()).getYear());

            System.out.println("Heard");
            System.out.print("reading:");
            System.out.print((int)getPercHeard(thing, "reading"));
            System.out.print(" art:");
            System.out.print((int)getPercHeard(thing, "art"));
            System.out.print(" sports:");
            System.out.print((int)getPercHeard(thing, "sports"));
            System.out.print(" music:");
            System.out.println((int)getPercHeard(thing, "music"));

            System.out.println("Likes");
            System.out.print("reading:");
            System.out.print((int)getPercLiked(thing, "reading"));
            System.out.print(" art:");
            System.out.print((int)getPercLiked(thing, "art"));
            System.out.print(" sports:");
            System.out.print((int)getPercLiked(thing, "sports"));
            System.out.print(" music:");
            System.out.println((int)getPercLiked(thing, "music"));
            System.out.println();
        }
        // GENERATION OF PROGRAM
        // GUIMusicWindow GUI = new GUIMusicWindow(mix, par);
    }


    /**
     * Scans the song file and generates a new mixtape of all the songs
     * 
     * @param arg
     *            File to parse
     * @return Mixtape of all the songs
     * @throws FileNotFoundException
     */
    public Mixtape readFile1(File arg) throws FileNotFoundException {
        Mixtape ans = new Mixtape();
        Scanner scan = new Scanner(arg);
        scan.nextLine();
        // Parse data
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] split = line.split(",");
            String title = split[0];
            String artist = split[1];
            int year = Integer.valueOf(split[2]);
            String genre = split[3];
            // Create new song based on gathered data
            Song s = new Song(title, artist, genre, year);
            // System.out.println(s);
            ans.addSong(s);
        }
        scan.close();
        return ans;
    }


    /**
     * Scans the response file and generates a new party of all the students
     * 
     * @param arg
     *            File to parse
     * @return Party of all the students
     * @throws FileNotFoundException
     */
    public Party readFile2(File arg) throws FileNotFoundException {
        Party ans = new Party();

        Scanner scan = new Scanner(arg);
        scan.nextLine();
        String major = "";
        String region = "";
        String hobby = "";
        int i = 0;
        // Parse data
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] split = line.split(",");
            // Empty line
            if (split.length <= 5) {
                line = scan.nextLine();
                split = line.split(",");
            }

            //set conditions for inner while loop
            int num = 5;
            boolean addStudent = true;

            while ((num) < split.length) {
                // Parse major, region, and hobby
                Student s = new Student("m", "r", "h");
                major = split[2];
                region = split[3];
                hobby = split[4];
                s.setMajor(major);
                s.setRegion(region);
                s.setHobby(hobby);

                //add the student to the party of students
                if (addStudent) {
                    ans.addStudent(s);
                    addStudent = false;
                }

                String r1 = split[num];
                String r2 = "";
                num++;
                if (num < split.length) {
                    r2 = split[num];
                    num++;
                }

                // Create new student, set responses
                Student toAdd = s;
                toAdd.setInput(r1, r2);

                // Add student object which holds two responses to group in song
                songArray[i].addStudent(toAdd);
                i++;
            }

            // Reset parameters
            i = 0;
            num = 0;
            addStudent = true;
        }
        scan.close();
        return ans;
    }

    /**
     * gives the percent of people from a specific hobby that have heard the song
     * @param thing the SortCategories object to test
     * @param hobby the hobby to sort by
     * @return
     */
    public double getPercHeard(SortCategories thing, String hobby) {
        return (double) (100 * thing.sortByHobby(hobby).numHeardSong())
            / thing.sortByHobby(hobby).totalAnsHeard();
    }

    /**
     * gives the percent of people from a specific hobby that have liked the song
     * @param thing the SortCategories object to test
     * @param hobby the hobby to sort by
     * @return
     */
    public double getPercLiked(SortCategories thing, String hobby) {
        return (double) (100 * thing.sortByHobby(hobby).numLikedSong())
            / thing.sortByHobby(hobby).totalAnsLiked();
    }
}
