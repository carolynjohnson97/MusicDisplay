package prj5;

import java.util.Iterator;

/**
 * Stores each student in a singly linked list to form a party
 * 
 * @author alexmann and carolynj
 * @version 04/18/17
 *
 */
public class Party {
    private LinkedList<Student> list;


    /**
     * Constructor to instantiate a new party as a linked list
     */
    public Party() {
        list = new LinkedList<Student>();
    }


    /**
     * Getter method for list representing party
     * 
     * @return The current list as it stands
     */
    public LinkedList<Student> getList() {
        return list;
    }


    /**
     * Adds a student to the list
     * 
     * @param stud
     *            Student to be added to the list
     */
    public void addStudent(Student stud) {
        list.add(stud);
    }


    /**
     * Determines number of students who heard the song
     * 
     * @return Number of students (int)
     */
    public int numHeardSong() {
        Iterator<Student> iterator = list.iterator();
        int sum = 0;
        while (iterator.hasNext()) {
            String[] responses = (iterator.next()).getInput();
            if (responses[0].equalsIgnoreCase("yes")) {
                sum++;
            }
        }
        return sum;
    }
    
    /**
     * gives the total number of people who responded to the heard question
     * @return  number of students who responded
     */
    public int totalAnsHeard() {
        Iterator<Student> iterator = list.iterator();
        int sum = 0;
        while (iterator.hasNext()) {
            String[] responses = (iterator.next()).getInput();
            if (responses[0].equalsIgnoreCase("yes")
                || responses[0].equalsIgnoreCase("no")) {
                sum++;
            }
        }
        return sum;
    }

    /**
     * Determines number of students who liked the song
     * 
     * @return Number of students (int)
     */
    public int numLikedSong() {
        Iterator<Student> iterator = list.iterator();
        int sum = 0;
        while (iterator.hasNext()) {
            String[] responses = (iterator.next()).getInput();
            if (responses[1].equalsIgnoreCase("yes")) {
                sum++;
            }
        }
        return sum;
    }
    
    /**
     * gives the total number of people who responded to the liked question
     * @return  number of students who responded
     */
    public int totalAnsLiked() {
        Iterator<Student> iterator = list.iterator();
        int sum = 0;
        while (iterator.hasNext()) {
            String[] responses = (iterator.next()).getInput();
            if (responses[1].equalsIgnoreCase("yes")
                || responses[1].equalsIgnoreCase("no")) {
                sum++;
            }
        }
        return sum;
    }


    /**
     * returns the number of students in the party
     * 
     * @return size
     */
    public int getSize() {
        return list.size();
    }


    /**
     * returns a String form of the party by listing all of the students and
     * their respective major, region, hobby, and input
     * @return the String form of Party
     */
    public String toString() {
        StringBuilder build = new StringBuilder();
        build.append("[");
        for (int i = 0; i < list.size(); i++) {
            build.append(list.get(i).getMajor());
            build.append(", ");
            build.append(list.get(i).getRegion());
            build.append(", ");
            build.append(list.get(i).getHobby());
            build.append(", ");
            build.append(list.get(i).getInput()[0]);
            build.append(", ");
            build.append(list.get(i).getInput()[1]);
        }
        build.append("]");
        return build.toString();
    }

}
