package prj5;

import java.io.FileNotFoundException;

public class Input {
    public static void main(String[] arg) throws FileNotFoundException {
        if (arg.length > 0) {
            FileReader fr = new FileReader(arg[0], arg[1]);
        }
        else {
            FileReader fr = new FileReader("MusicSurveyDataNoGenreRepeats.csv",
                "SongListNoGenreRepeats.csv");
        }
    }
}
