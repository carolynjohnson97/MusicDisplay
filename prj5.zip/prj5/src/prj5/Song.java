package prj5;

/**
 * Creates an object of type song to hold all of the information
 * for each song in the playlist
 * 
 * @author Carolyn Johnson (carolynj)
 * @version 2017.04.18
 *
 */
public class Song implements Comparable<Song> {
    private String title;
    private int year;
    private String artist;
    private String genre;
    private Party party;
    private LinkedList<Party> parties;
    private String category;


    /**
     * Creates a new song object with the given title, artist
     * genre, and year
     * 
     * @param tit
     *            the title of the song
     * @param art
     *            the artist of the song
     * @param gen
     *            the genre of the song
     * @param yea
     *            the year the song came out
     */
    public Song(String tit, String art, String gen, int yea) {
        title = tit;
        artist = art;
        genre = gen;
        year = yea;
        party = new Party();
        parties = new LinkedList<>();
    }


    /**
     * gets the title of the song
     * 
     * @return title of the song
     */
    public String getTitle() {
        return title;

    }


    /**
     * gets the year of the song
     * 
     * @return year of the song
     */
    public int getYear() {
        return year;

    }


    /**
     * gets the artist of the song
     * 
     * @return artist of the song
     */
    public String getArtist() {
        return artist;

    }


    /**
     * gets the genre of the song
     * 
     * @return genre of the song
     */
    public String getGenre() {
        return genre;

    }


    /**
     * gives the song in the form of a string formatted as,
     * "[title, genre, artist, year]"
     * 
     * @return the string form of the song
     */
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        builder.append(title);
        builder.append(", ");
        builder.append(genre);
        builder.append(", ");
        builder.append(artist);
        builder.append(", ");
        builder.append(year);
        builder.append("]");
        return builder.toString();
    }


    /**
     * tells whether two songs are the same by comparing the titles,
     * artists, years, and genres
     * 
     * @param obj
     *            the object to be tested if it's equal or not
     * @return true if they have everything the same
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() == obj.getClass()) {
            Song song = (Song)obj;
            return (this.getTitle() == song.getTitle() && this.getGenre()
                .equals(song.getGenre()) && this.getArtist().equals(song
                    .getArtist()) && this.getYear() == (song.getYear()));
        }
        else {
            return false;
        }
    }


    /**
     * gives the party of people who liked the song
     * 
     * @return party of people who liked the song
     */
    public Party getParty() {
        return party;
    }


    /**
     * adds the given party to the LinkedList of parties
     * 
     * @param party
     *            the party to be added to the LinkedList
     */
    public void addPartyToList(Party party) {
        parties.add(party);
    }


    /**
     * clears the LinkedList of parties
     */
    public void clearList() {
        parties.clear();
    }


    /**
     * adds the given student to the party of people's responses
     * 
     * @param student
     *            the student to be added to the list
     */
    public void addStudent(Student student) {
        party.addStudent(student);
    }


    /**
     * gives the list of parties
     * 
     * @return parties
     */
    public LinkedList<Party> getList() {
        return parties;
    }


    /**
     * sets the category the songs will be sorted by with the given
     * category
     * 
     * @param category
     *            the category the songs will be sorted by
     */
    public void setSortingCategory(String category) {
        this.category = category;
    }


    /**
     * gives the category the songs will be sorted by
     * 
     * @return category
     */
    public String getCategory() {
        return category;
    }


    @Override
    public int compareTo(Song song) {
        if (this.getCategory().equalsIgnoreCase("artist")) {
            return this.getArtist().compareTo(song.getArtist());
        }
        else if (this.getCategory().equalsIgnoreCase("genre")) {
            return this.getGenre().compareTo(song.getGenre());
        }
        else if (this.getCategory().equalsIgnoreCase("year")) {
            return this.getYear() - song.getYear();
        }
        // default to title
        else {
            return this.getTitle().compareTo(song.getTitle());
        }
    }

}
