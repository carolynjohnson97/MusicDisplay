package prj5;

import java.util.Iterator;

/**
 * Sorts a given party by either hobby, region, or major
 * 
 * @author alexmann
 * @version 04/18/17
 *
 */
public class SortCategories {
    private Party party;


    /**
     * Constructor instantiates a new party to be sorted
     * 
     * @param par
     *            Party to be sorted
     */
    public SortCategories(Party par) {
        party = par;
    }


    /**
     * Getter method for party
     * 
     * @return party
     */
    public Party getParty() {
        return party;
    }


    /**
     * Creates a new party containing only those students who share the given
     * hobby
     * 
     * @param hobby
     *            Desired hobby
     * @return New party with only shared hobbies
     */
    public Party sortByHobby(String hobby) {
        Party ans = new Party();
        Iterator<Student> iterator = party.getList().iterator();
        // Traverse through party and pace all students with the parameter hobby
        // in a new party
        while (iterator.hasNext()) {
            Student s = iterator.next();
            if (s.getHobby().equals(hobby)) {
                ans.addStudent(s);
            }
        }
        return ans;
    }


    /**
     * Creates a new party containing only those students who share the given
     * region
     * 
     * @param region
     *            Desired region
     * @return New party with only shared regions
     */
    public Party sortByRegion(String region) {
        Party ans = new Party();
        Iterator<Student> iterator = party.getList().iterator();
        // Traverse through party and pace all students with the parameter
        // region
        // in a new party
        while (iterator.hasNext()) {
            Student s = iterator.next();
            if (s.getRegion().equals(region)) {
                ans.addStudent(s);
            }
        }
        return ans;
    }


    /**
     * Creates a new party containing only those students who share the given
     * major
     * 
     * @param major
     *            Desired major
     * @return New party with only shared majors
     */
    public Party sortByMajor(String major) {
        Party ans = new Party();
        Iterator<Student> iterator = party.getList().iterator();
        // Traverse through party and pace all students with the parameter major
        // in a new party
        while (iterator.hasNext()) {
            Student s = iterator.next();
            if (s.getMajor().equals(major)) {
                ans.addStudent(s);
            }
        }
        return ans;
    }
}