package prj5;

public class StudentTest extends student.TestCase {
    private Student stud;


    public void setUp() {
        stud = new Student("Biology", "Roanoke", "Sports");
    }


    public void testSetInput() {
        stud.setInput("yes", "no");
        String[] test = stud.getInput();
        assertEquals(test[0], "yes");
        assertEquals(test[1], "no");
    }


    public void testGetInput() {
        stud.setInput("yes", "yes");
        String[] test = stud.getInput();
        assertEquals(test.length, 2);
    }


    public void testGetMajor() {
        assertEquals("Biology", stud.getMajor());
    }


    public void testGetRegion() {
        assertEquals("Roanoke", stud.getRegion());
    }


    public void testGetHobby() {
        assertEquals("Sports", stud.getHobby());
    }
}
