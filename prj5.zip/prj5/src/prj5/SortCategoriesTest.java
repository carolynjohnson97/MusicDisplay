package prj5;

/**
 * Test class for SortCategories
 * 
 * @author alexmann, carolynj, jaib97
 * @version 04/18/17
 *
 */
public class SortCategoriesTest extends student.TestCase {
    private SortCategories sort;
    private Student stud1;
    private Student stud2;
    private Student stud3;


    /**
     * SetUp method instantiates variables for testing
     */
    public void setUp() {
        Party p = new Party();
        stud1 = new Student("A", "B", "A");
        stud2 = new Student("", "C", "B");
        stud3 = new Student("G", "C", "A");
        p.addStudent(stud1);
        p.addStudent(stud2);
        p.addStudent(stud3);
        sort = new SortCategories(p);
    }


    /**
     * Tests SortCategory's getParty()
     */
    public void testGetParty() {
        assertNotNull(sort.getParty());
    }


    /**
     * Tests SortCategory's sortByHobby()
     */
    public void testSortByHobby() {
        sort.sortByHobby("A");
        Party party = new Party();
        party.addStudent(stud1);
        party.addStudent(stud3);
        assertEquals(party, sort.getParty());
    }


    /**
     * Tests SortCategory's sortByRegion()
     */
    public void testSortByRegion() {
        sort.sortByRegion("C");
        Party party = new Party();
        party.addStudent(stud2);
        party.addStudent(stud3);
        assertEquals(party, sort.getParty());
    }


    /**
     * Tests SortCategory's sortByMajor()
     */
    public void testSortByMajor() {
        sort.sortByHobby("A");
        Party party = new Party();
        party.addStudent(stud1);
        assertEquals(party, sort.getParty());
    }
}