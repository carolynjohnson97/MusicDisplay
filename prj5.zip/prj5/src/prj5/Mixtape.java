package prj5;

public class Mixtape {
    // Fields-------------------------------------------------
    /**
     * list of songs
     */
    private LinkedList<Song> list;


    // Constructor--------------------------------------------
    /**
     * constructor that makes a Mixtape object by initializing the list of songs
     */
    public Mixtape() {
        list = new LinkedList<Song>();
    }


    // Methods-------------------------------------------------
    /**
     * gives the list of songs
     * 
     * @return list of songs
     */
    public LinkedList<Song> getList() {
        return list;
    }


    /**
     * sets the list of songs to the given list
     * 
     * @param list
     *            the list that this list is being set to
     */
    public void setList(LinkedList<Song> list) {
        this.list = list;
    }


    /**
     * adds the given song to the list of songs
     * 
     * @param song
     *            the song to be added to the list
     */
    public void addSong(Song song) {
        list.add(song);
    }


    /**
     * turns the list of songs into an array and returns it
     * 
     * @return the array version of the list of songs
     */
    public Song[] toArray() {
        Song[] result = new Song[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        return result;
    }

}