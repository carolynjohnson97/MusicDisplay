/**
 * 
 */
package prj5;

import student.TestCase;

/**
 * @author Carolyn Johnson (carolynj)
 * @version 2017.04.18
 *
 */
public class SongTest extends TestCase {

    // Fields------------------------------------------------

    /**
     * Song1 to test methods on
     */
    private Song song1;

    /**
     * Song2 to test methods on and compare to song1
     */
    private Song song2;

    private Student stud;

    private Student stud1;

    private Student stud2;


    // setUp-------------------------------------------------

    /**
     * sets up the test cases and initializes the two songs
     */
    public void setUp() {
        song1 = new Song("Get Lucky", "Daft Punk", "Punk", 2005);
        song2 = new Song("tik tok", "kesha", "pop", 2010);
        stud = new Student("hobby", "major", "state");
        stud1 = new Student("balling", "cmda", "va");
        stud2 = new Student("ball", "math", "fl");
    }


    // test methods------------------------------------------

    /**
     * tests the getTitle() method
     */
    public void testGetTitle() {
        assertEquals(song1.getTitle(), "Get Lucky");
        assertEquals(song2.getTitle(), "tik tok");
    }


    /**
     * tests the getYear() method
     */
    public void testGetYear() {
        assertEquals(song1.getYear(), 2005, 0.1);
        assertEquals(song2.getYear(), 2010, 0.1);
    }


    /**
     * tests the getArtist() method
     */
    public void testGetArtist() {
        assertEquals(song1.getArtist(), "Daft Punk");
        assertEquals(song2.getArtist(), "kesha");
    }


    /**
     * tests the getGenre() method
     */
    public void testGetGenre() {
        assertEquals(song1.getGenre(), "Punk");
        assertEquals(song2.getGenre(), "pop");
    }


    /**
     * tests the toString() method
     */
    public void testToString() {
        assertEquals(song1.toString(), "[Get Lucky, Punk, Daft Punk, 2005]");
        assertEquals(song2.toString(), "[tik tok, pop, kesha, 2010]");
    }


    /**
     * tests the equals() method
     */
    public void testEquals() {
        Song nullSong = null;
        Song song3 = new Song("Get Lucky", "l", "t", 2003);
        Song song4 = new Song("t", "Daft Punk", "t", 2003);
        Song song5 = new Song("f", "l", "Punk", 2003);
        Song song6 = new Song("f", "l", "t", 2005);
        Song song7 = new Song("Get Lucky", "Daft Punk", "Punk", 2005);

        // tests on the same object
        assertTrue(song1.equals(song1));

        // tests on a null object
        assertFalse(song1.equals(nullSong));

        // tests on an object of a different class
        assertFalse(song1.equals("song1"));

        // tests on different everything
        assertFalse(song1.equals(song2));

        // tests on same title different everything else
        assertFalse(song1.equals(song3));

        // tests on same artist different everything else
        assertFalse(song1.equals(song4));

        // tests on same genre different everything else
        assertFalse(song1.equals(song5));

        // tests on same year different everything else
        assertFalse(song1.equals(song6));

        // tests same everything
        assertTrue(song1.equals(song7));

    }


    /**
     * tests the setSortingCategory() method
     */
    public void testSetSortingCategory() {
        song1.setSortingCategory("Genre");
        assertEquals(song1.getCategory(), "Genre");
    }


    /**
     * tests the getSortingCategory() method
     */
    public void testGetSortingCategory() {
        song1.setSortingCategory("Genre");
        assertEquals(song1.getCategory(), "Genre");
    }


    public void testWhatever() {
        Party party = new Party();
        party.addStudent(stud);
        party.addStudent(stud1);
        party.addStudent(stud2);
        song1.addPartyToList(party);
        assertTrue(song1.getList().contains(party));
        assertEquals(song1.getList().size(), 1);
        song1.clearList();
        assertFalse(song1.getList().contains(party));
        assertEquals(song1.getList().size(), 0);
    }
    

}
