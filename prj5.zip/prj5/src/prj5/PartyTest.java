package prj5;

/**
 * Test class for Party
 * 
 * @author alexmann, carolynj, jaib97
 * @version 04/18/17
 *
 */
public class PartyTest extends student.TestCase {
    private Party party;


    /**
     * Setup method instantiates a new party for testing
     */
    public void setUp() {
        party = new Party();
    }


    /**
     * Tests Party's getList()
     */
    public void testGetList() {
        party.addStudent(new Student("1", "2", "3"));
        assertNotNull(party.getList());
    }


    /**
     * Tests Party's addStudent()
     */
    public void testAddStudent() {
        for (int i = 0; i < 5; i++) {
            party.addStudent(new Student("Biology" + i, "Roanoke" + i, "Sports"
                + i));
        }
        assertEquals(5, party.getList().size());
    }


    /**
     * Tests Party's numHearSong()
     */
    public void testNumHeardSong() {
        for (int i = 0; i < 5; i++) {
            Student s = new Student("" + i, "" + i, "" + i);
            // Setting different responses for students
            if (i == 0) {
                s.setInput("", "");
            }
            else if (i % 2 == 0) {
                s.setInput("yes", "yes");
            }
            else {
                s.setInput("yes", "no");
            }
            // Add each one to party
            party.addStudent(s);
        }
        assertEquals(4, party.numHeardSong());
        assertEquals(2, party.numLikedSong());
    }


    /**
     * Tests Party's numLikedSong()
     */
    public void testNumLikedSong() {
        for (int i = 0; i < 5; i++) {
            Student s = new Student("" + i, "" + i, "" + i);
            // Setting different responses for students
            if (i == 0) {
                s.setInput("", "");
            }
            else if (i % 2 == 0) {
                s.setInput("yes", "yes");
            }
            else {
                s.setInput("no", "yes");
            }
            // Add each one to party
            party.addStudent(s);
        }
        assertEquals(2, party.numHeardSong());
        assertEquals(4, party.numLikedSong());
    }

}
