package prj5;

import java.util.Arrays;

/**
 * Class organizes songs based on categories given
 * 
 * @author Carolyn Johnson (carolynj)
 * @version 2017.04.19
 */
public class SongOrganization extends LinkedList<Song> {
    // Fields------------------------------------------------
    /**
     * the list of songs needed to be organized
     */
    private LinkedList<Song> songList;

    /**
     * the category to sort the songs by
     */
    private String category;


    // Constructor-------------------------------------------
    /**
     * Creates a SongOrganization object with the given mixtape
     * and type
     * 
     * @param mix
     *            the list of songs to be organized
     * @param type
     *            the category the songs will be sorted by
     */
    public SongOrganization(Mixtape mix, String type) {
        // initialize fields
        songList = mix.getList();
        category = type;

        // add the songs from songList to the SongOrganization object
        for (int i = 0; i < songList.size(); i++) {
            this.add(songList.get(i), category);
        }
    }


    // Methods------------------------------------------------

    /**
     * gives the list of songs that is being organized
     * 
     * @return songList (list of songs)
     */
    public LinkedList<Song> getSongList() {
        return songList;
    }


    /**
     * adds the given song in the order based on the given category
     * 
     * @param song
     *            the song to be added to the list
     * @param category
     *            determines the order of the list for where the song should go
     * @return true if the song successfully added
     */
    public boolean add(Song song, String category) {
        song.setSortingCategory(category);

        // add the song to the list
        this.add(song);

        // sort the list
        Song[] songs = new Song[this.size()];
        for (int i = 0; i < this.size(); i++) {
            songs[i] = this.get(i);
        }

        Arrays.sort(songs);

        this.clear();
        for (int i = 0; i < songs.length; i++) {
            this.add(songs[i]);
        }

        return true;
    }

    /**
     * gives the node of the list at the given index
     * 
     * @param index
     *            the index where the node we want is
     * @return the node at the given index
     */
    @SuppressWarnings("rawtypes")
    public Node getNode(int index) {
        Node curr = getHead();
        for (int i = 0; i < index; i++) {
            curr = curr.next();
        }
        return curr;

    }

}
