package prj5;

import java.awt.Color;
import CS2114.Button;
import CS2114.Shape;
import CS2114.TextShape;
import CS2114.Window;
import CS2114.WindowSide;

/**
 * 
 * @author alexmann, carolynj, jaib97
 * @version 04/18/17
 *
 */
public class GUIMusicWindow {
    Mixtape mixtape;
    Party party;
    private Window window;
    private Button previous;
    private Button next;
    private Button artistName;
    private Button songTitle;
    private Button releaseYear;
    private Button genre;
    private Button repHobby;
    private Button repMajor;
    private Button repRegion;
    private Button quit;
    private boolean hobby;
    private boolean major;
    private boolean region;
    private String type;


    /**
     * Front End Constructor: Generates buttons/shapes and places them on the
     * window. Additionally, checks for clicked buttons and calls the
     * appropriate methods
     * 
     */
    public GUIMusicWindow(Mixtape mix, Party par) {
        mixtape = mix;
        party = par;
        // Creating Buttons
        window = new Window();
        previous = new Button("<- Prev");
        next = new Button("Next");
        artistName = new Button("Sort by Artist Name");
        songTitle = new Button("Sort by Song Title");
        releaseYear = new Button("Sort by Release Year");
        genre = new Button("Sort by Genre");
        next = new Button("Next ->");
        repHobby = new Button("Represent Hobby");
        repMajor = new Button("Represent Major");
        repRegion = new Button("Represent Region");
        quit = new Button("Quit");
        // Adding buttons to window
        window.addButton(previous, WindowSide.NORTH);
        window.addButton(artistName, WindowSide.NORTH);
        window.addButton(songTitle, WindowSide.NORTH);
        window.addButton(releaseYear, WindowSide.NORTH);
        window.addButton(genre, WindowSide.NORTH);
        window.addButton(next, WindowSide.NORTH);
        window.addButton(repHobby, WindowSide.SOUTH);
        window.addButton(repMajor, WindowSide.SOUTH);
        window.addButton(repRegion, WindowSide.SOUTH);
        window.addButton(quit, WindowSide.SOUTH);
        // Creating Legend
        TextShape hobbyLegend = new TextShape(600, 135, "Hobby Legend"); // Subject
                                                                         // to
                                                                         // change
        TextShape read = new TextShape(600, 150, "Read");
        TextShape art = new TextShape(600, 165, "Art");
        TextShape sports = new TextShape(600, 180, "Sports");
        TextShape music = new TextShape(600, 195, "Music");
        TextShape legendSongTitle = new TextShape(625, 210, "Song Title");
        TextShape heard = new TextShape(615, 235, "Heard");
        TextShape likes = new TextShape(670, 235, "Likes");
        Shape bar = new Shape(662, 230, 5, 30);
        Shape left = new Shape(595, 130, 1, 135);
        Shape right = new Shape(715, 130, 1, 135);
        Shape top = new Shape(595, 130, 120, 1);
        Shape bottom = new Shape(595, 265, 135, 1);
        // Setting legend colors
        hobbyLegend.setBackgroundColor(Color.WHITE);
        read.setBackgroundColor(Color.WHITE);
        read.setForegroundColor(Color.PINK);
        art.setBackgroundColor(Color.WHITE);
        art.setForegroundColor(Color.BLUE);
        sports.setBackgroundColor(Color.WHITE);
        sports.setForegroundColor(Color.YELLOW);
        music.setBackgroundColor(Color.WHITE);
        music.setForegroundColor(Color.GREEN);
        legendSongTitle.setBackgroundColor(Color.WHITE);
        heard.setBackgroundColor(Color.WHITE);
        likes.setBackgroundColor(Color.WHITE);
        bar.setBackgroundColor(Color.BLACK);
        // Adding legend to window
        window.addShape(hobbyLegend);
        window.addShape(read);
        window.addShape(art);
        window.addShape(sports);
        window.addShape(music);
        window.addShape(legendSongTitle);
        window.addShape(heard);
        window.addShape(likes);
        window.addShape(bar);
        window.addShape(top);
        window.addShape(bottom);
        window.addShape(left);
        window.addShape(right);
        // Creating glyph
        Shape bar1 = new Shape(50, 50, 70, 8);
        bar1.setBackgroundColor(Color.PINK);
        Shape bar2 = new Shape(60, 58, 85, 8);
        bar2.setBackgroundColor(Color.BLUE);
        Shape bar3 = new Shape(45, 66, 90, 8);
        bar3.setBackgroundColor(Color.YELLOW);
        Shape bar4 = new Shape(55, 74, 70, 8);
        bar4.setBackgroundColor(Color.GREEN);
        Shape vertical = new Shape(100, 50, 4, 30);
        vertical.setBackgroundColor(Color.BLACK);
        window.addShape(bar1);
        window.addShape(bar2);
        window.addShape(bar3);
        window.addShape(bar4);
        window.addShape(vertical);
        window.moveToFront(vertical);
        // Checking for when buttons are clicked
        previous.onClick(this, "clickedPrevious");
        artistName.onClick(this, "clickedSortByArtistName");
        songTitle.onClick(this, "clickedSortBySongTitle");
        releaseYear.onClick(this, "clickedSortByYear");
        genre.onClick(this, "clickedSortByGenre");
        next.onClick(this, "clickedNext");
        repHobby.onClick(this, "clickedRepresentHobby");
        repMajor.onClick(this, "clickedRepresentMajor");
        repRegion.onClick(this, "clickedRepresentRegion");
        quit.onClick(this, "clickedQuit");

    }


    public void clickedPrevious(Button button) {

    }


    public void clickedNext() {

    }


    public void sortByArtistName() {

    }


    public void clickedSortBySongTitle() {

    }


    public void clickedSortByReleaseYear() {

    }


    public void clickedSortByGenre() {

    }


    public void clickedRepresentHobby() {

    }


    public void clickedRepresentMajor() {

    }


    public void clickedRepresentRegion() {

    }


    public void clickedQuit() {

    }


    private void update() {

    }


    public void changeShapes() {

    }


    public void addShapes() {

    }


    public void createGraph() {

    }

}
