/**
 * 
 */
package prj5;
import student.TestCase;

/**
 * @author Carolyn Johnson (carolynj)
 * @version 2017.04.19
 */
public class SongOrganizationTest extends TestCase {

    //Field
    private SongOrganization sort;

    /**
     * Sets up the SongOrganizationTest class
     */
    public void setUp()
    {
        Mixtape tape = new Mixtape();        
        sort = new SongOrganization(tape, "type");
    }
    /**
     * Tests add to make sure it runs as expected
     */
    public void testAdd()
    {
        Mixtape empty = new Mixtape();

        //songs to test title and the test for testing title
        Song song1 = new Song("d-title", "a-artist", "a-genre", 2011);
        Song song2 = new Song("b-title", "b-artist", "b-genre", 2012);
        Song song3 = new Song("c-title", "c-artist", "c-genre", 2013);
        Song song4 = new Song("a-title", "d-artist", "d-genre", 2014);

        SongOrganization sortTitle = new SongOrganization(empty, "title");

        assertTrue(sortTitle.add(song1, "title"));       
        assertTrue(sortTitle.add(song2, "title"));
        assertTrue(sortTitle.add(song3, "title"));
        assertTrue(sortTitle.add(song4, "title"));

        //System.out.println(sortTitle);

        assertEquals(sortTitle.getNode(1).getData(), song4);     
        assertEquals(sortTitle.getNode(2).getData(), song2); 
        assertEquals(sortTitle.getNode(3).getData(), song3); 
        assertEquals(sortTitle.getNode(4).getData(), song1);

        //songs to test artist
        Song song5 = new Song("a-title", "c-artist", "a-genre", 2011);
        Song song6 = new Song("b-title", "b-artist", "b-genre", 2012);
        Song song7 = new Song("c-title", "a-artist", "c-genre", 2013);
        Song song8 = new Song("d-title", "d-artist", "d-genre", 2014);

        SongOrganization sortArtist = new SongOrganization(empty, "artist");

        assertTrue(sortArtist.add(song5, "artist"));
        assertTrue(sortArtist.add(song6, "artist"));
        assertTrue(sortArtist.add(song7, "artist"));
        assertTrue(sortArtist.add(song8, "artist"));

        //System.out.println(sortArtist);

        assertEquals(sortArtist.getNode(1).getData(), song7);     
        assertEquals(sortArtist.getNode(2).getData(), song6); 
        assertEquals(sortArtist.getNode(3).getData(), song5); 
        assertEquals(sortArtist.getNode(4).getData(), song8);

        //songs to test genre
        Song song9 = new Song("a-title", "a-artist", "b-genre", 2011);
        Song song10 = new Song("b-title", "b-artist", "a-genre", 2012);
        Song song11 = new Song("c-title", "c-artist", "d-genre", 2013);
        Song song12 = new Song("d-title", "d-artist", "c-genre", 2014);

        SongOrganization sortGenre = new SongOrganization(empty, "genre");

        assertTrue(sortGenre.add(song9, "Genre"));
        assertTrue(sortGenre.add(song10, "Genre"));
        assertTrue(sortGenre.add(song11, "Genre"));
        assertTrue(sortGenre.add(song12, "Genre"));

        //System.out.println(sortGenre);

        assertEquals(sortGenre.getNode(1).getData(), song10);     
        assertEquals(sortGenre.getNode(2).getData(), song9); 
        assertEquals(sortGenre.getNode(3).getData(), song12); 
        assertEquals(sortGenre.getNode(4).getData(), song11);

        //songs to test year
        Song song13 = new Song("a-title", "a-artist", "a-genre", 2014);
        Song song14 = new Song("b-title", "b-artist", "b-genre", 2011);
        Song song15 = new Song("c-title", "c-artist", "c-genre", 2013);
        Song song16 = new Song("d-title", "d-artist", "d-genre", 2012);

        SongOrganization sortYear = new SongOrganization(empty, "Year");

        assertTrue(sortYear.add(song13, "Year"));
        assertTrue(sortYear.add(song14, "Year"));
        assertTrue(sortYear.add(song15, "Year"));
        assertTrue(sortYear.add(song16, "Year"));

        //System.out.println(sortYear);

        assertEquals(sortYear.getNode(1).getData(), song14);     
        assertEquals(sortYear.getNode(2).getData(), song16); 
        assertEquals(sortYear.getNode(3).getData(), song15); 
        assertEquals(sortYear.getNode(4).getData(), song13);
    }

    /**
     * Tests getNode to make sure it runs as expected
     */
    public void testGetNode()
    {
        //test on songs that are added directly to SongOrganization object
        Song song1 = new Song ("btitle", "artist", "genre", 2010);
        Song song2 = new Song ("atitle", "artist", "genre", 2010);
        Song song3 = new Song ("ctitle", "artist", "genre", 2010);

        sort.add(song1, "title");
        sort.add(song2, "title");
        sort.add(song3, "title");
        assertEquals(sort.getNode(1).getData(), song2);     
        assertEquals(sort.getNode(2).getData(), song1); 
        assertEquals(sort.getNode(3).getData(), song3); 

        //test on SongOrganization Object that already has songs
        Mixtape test = new Mixtape();
        test.addSong(song1);
        test.addSong(song2);
        test.addSong(song3);

        SongOrganization tester = new SongOrganization(test, "title");

        assertEquals(tester.getNode(1).getData(), song2);     
        assertEquals(tester.getNode(2).getData(), song1); 
        assertEquals(tester.getNode(3).getData(), song3); 

    }
    /**
     * Tests getMixtape to make sure it runs as expected
     */
    public void testGetSongList()
    {
        //song adds to the SongOrganization object, but not the mixtape
        Song song = new Song("title", "artist", "genre", 2016);
        assertTrue(sort.add(song, "Year"));
        assertTrue(sort.contains(song));
        assertFalse(sort.getSongList().contains(song)); 
        assertEquals(sort.getSongList().size(), 0);   


        //test with a SongOrganization object made with a filled mixtape
        Mixtape tape3 = new Mixtape();
        Song song1 = new Song("atitle", "cartist", "bgenre", 2016);
        Song song2 = new Song("btitle", "aartist", "cgenre", 2017);
        Song song3 = new Song("ctitle", "bartist", "agenre", 2018);
        tape3.addSong(song1);
        tape3.addSong(song2);
        tape3.addSong(song3);
        SongOrganization test = new SongOrganization(tape3, "Title");
        assertTrue(test.getSongList().contains(song1));
        assertTrue(test.getSongList().contains(song2));
        assertTrue(test.getSongList().contains(song3));

    }
    
    public void testSomething() {
        Mixtape tape3 = new Mixtape();
        Song song1 = new Song("atitle", "cartist", "bgenre", 2016);
        Song song2 = new Song("atitle", "cartist", "bgenre", 2016);
        Song song3 = new Song("atitle", "cartist", "bgenre", 2016);
        tape3.addSong(song1);
        tape3.addSong(song2);
        tape3.addSong(song3);
        SongOrganization test = new SongOrganization(tape3, "Title");
        assertTrue(test.getSongList().contains(song1));
        assertTrue(test.getSongList().contains(song2));
        assertTrue(test.getSongList().contains(song3));
        for (int i = 1; i <= test.size(); i++) {
            System.out.println(test.getNode(i).getData());
        }
        System.out.println(test);
    }
}
