package prj5;

/**
 * Retains information regarding a student's major, region, and hobby as well as
 * 
 * @author alexmann and carolynj
 * @version 04/18/17
 *
 */
public class Student {
    private String major;
    private String region;
    private String hobby;
    private String[] input;


    /**
     * Constructor to instantiate major, region, and hobby variables
     * 
     * @param maj
     *            Major
     * @param reg
     *            Region
     * @param hob
     *            hobby
     */
    public Student(String maj, String reg, String hob) {
        major = maj;
        region = reg;
        hobby = hob;
    }


    /**
     * Sets the student responses to heard song and liked song in a size 2
     * string array
     * 
     * @param heard
     *            Whether or not the student has heard the song
     * @param liked
     *            Whether or not the student likes the song
     */
    public void setInput(String heard, String liked) {
        String[] s = new String[2];
        s[0] = heard;
        s[1] = liked;
        input = s;
    }


    /**
     * Getter method for student input responses
     * 
     * @return String array of size 2 with responses stored
     */
    public String[] getInput() {
        return input;
    }
    
    /**
     * set the major of the student to the given string
     * @param major the major for the student to be set to
     */
    public void setMajor(String major) {
        this.major = major;
    }


    /**
     * Getter method for major
     * 
     * @return Major (string)
     */
    public String getMajor() {
        return major;
    }
    
    /**
     * set the region of the student to the given string
     * @param region the region for the student to be set to
     */
    public void setRegion(String region) {
        this.region = region;
    }


    /**
     * Getter method for region
     * 
     * @return region (string)
     */
    public String getRegion() {
        return region;

    }
    
    /**
     * set the hobby of the student to the given string
     * @param hobby the hobby for the student to be set to
     */
    public void setHobby(String hobby) {
        this.hobby = hobby;
    }


    /**
     * Getter method for hobby
     * 
     * @return hobby (string)
     */
    public String getHobby() {
        return hobby;
    }
}